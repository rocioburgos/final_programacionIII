<?php
    use \Psr\Http\Message\ServerRequestInterface as Request;
    use \Psr\Http\Message\ResponseInterface as Response;
    use \Firebase\JWT\JWT as jwt; 
    require_once './vendor/autoload.php';
    require_once './Clases/anteojo.php';
    require_once './Clases/usuario.php';
    require_once './Clases/mw.php';
    require_once './Clases/ventas.php';
    $config['displayErrorDetails'] = true;
    $config['addContentLengthHeader'] = false;

    $app = new \Slim\App(["settings" => $config]);

    //A nivel de aplicacion un post ALTA ANTEOJOS
    $app->post('[/]', function (Request $request, Response $response) {   
      echo Anteojo::AgregarAnteojo($request,$response);   
        return $response;
    });

    $app->get('/anteojos', function (Request $request, Response $response) {   
        
        $json= Anteojo::TraerTodosAnteojos($request,$response);
       echo $json;
      //  $response=$json;
        return $response;

    });

    $app->post('/usuarios', function (Request $request, Response $response) {   
          
       $nuevoresponse=  Usuario::AgregarUsuario($request,$response);
        return $nuevoresponse;
    });
    
    $app->get('[/]', function (Request $request, Response $response) {   
        
       echo Usuario::TraerTodosUsuarios($request,$response);
        
        return $response;

    });


    //"::funcion"->cuando es de instancia
    //":funcion"->cuando es static
    $app->group('/login',function(){

        $this->post('[/]', function (Request $request, Response $response) {   
          
           echo Usuario::LoginUsuario($request,$response);
            return $response;
        })->add(\MW:: class ."::VerificarBD")->add(\MW:: class .":VerificarCamposVacios")->add(\MW:: class ."::VerificarSeteados");

        $this->get('[/]', function (Request $request, Response $response) {   
          
           echo (Usuario::VerificarTokenUsuario($request,$response));
           
            return $response;
        });

    });

    $app->group('/ventas',function(){

        $this->post('[/]', function (Request $request, Response $response) {   
          
           echo Ventas::AgregarVenta($request,$response);
            return $response;
        });
        $this->get('[/]', function (Request $request, Response $response) {   
          
            echo Ventas::TraerTodasVentas($request,$response);
           
            return $response;
        });
    });


    
    $app->delete("[/]",function(Request $request, Response $response){
        //Borrar anteojo por ID si es PROPIERARIO        
       echo Anteojo::EliminarAnteojo($request,$response);
        
        return $response;
    })->add(\MW::class."::VerificarToken")->add(\MW::class .":VerificarPropietario");


    $app->put("[/]",function(Request $request, Response $response){

        echo Anteojo::ModificarAnteojo($request,$response);
    })->add(MW::class."::VerificarPerfiles")->add(\MW::class."::VerificarToken");

   

    $app->group('/listado',function(){

        $this->post('[/]', function (Request $request, Response $response) { 
            $token = $request->getParsedBody()['token'];
            $encargado=Anteojo::EsEncargado($token);
          
            $arrayDeMedias= Anteojo::TraerTodosAnteojos($request,$response);
            if($encargado){
                //todos los datos menos el ID del listado
              
              $cant= count($arrayDeMedias);
               for($i=0;$i<$cant;$i++){
                $response->getBody()->write(  $arrayDeMedias[$i]->color." ".$arrayDeMedias[$i]->marca ." ".$arrayDeMedias[$i]->aumento." ".$arrayDeMedias[$i]->precio."<br>");
               }

           
            }  
            
        });

       
    });



$app->run();
?>