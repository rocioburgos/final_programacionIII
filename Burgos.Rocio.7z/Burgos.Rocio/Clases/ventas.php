<?php
 use \Firebase\JWT\JWT as jwt; 
    class Ventas{
        public function AgregarVenta($request,$response)//para el post
        {
           
                    $idAnteojo = $request->getParsedBody()['idAnteojo'];
                    $cantidad = $request->getParsedBody()['cantidad'];
                    $fecha = $request->getParsedBody()['fecha'];
            
          
                    $objetoPDO = new PDO('mysql:host=localhost;dbname=opticabd;charset=utf8', "root", "");
                    $consulta =$objetoPDO->prepare("INSERT INTO ventas_anteojos (id_Anteojos, cantidad, fecha) VALUES(:idAnteojo, :cantidad, :fecha)");
                    
                        $consulta->bindValue(':idAnteojo', $idAnteojo);
                        $consulta->bindValue(':cantidad', $cantidad);
                        $consulta->bindValue(':fecha', $fecha);
                       
                        $consulta->execute(); 
                     //   $response->getBody()->write("Usuario agregado con exito");
                   
                       // $response = $next($request, $response);
            
                return $response->withJson("Venta agregado con exito");


        }

        public function TraerTodasVentas($request,$response){
            $arrayDeUsuarios=array();
            $objetoPDO = new PDO('mysql:host=localhost;dbname=opticabd;charset=utf8', "root", "");
            $sql = $objetoPDO->prepare('SELECT * FROM ventas_anteojos');
            $sql->execute();
            
            while($result = $sql->fetchObject())
            {
              //  echo $result->correo." ".$result->nombre." ".$result->apellido." ".$result->perfil."<br>"; 
                array_push($arrayDeUsuarios,$result);
            }
           /* $cant= count($arrayDeUsuarios);
            for($i=0;$i<$cant;$i++){
             $response->getBody()->write($arrayDeUsuarios[$i]->nombre." ".$arrayDeUsuarios[$i]->apellido ." ".$arrayDeUsuarios[$i]->correo." ".$arrayDeUsuarios[$i]->perfil."<br>");
            }*/
            return $response->withJson($arrayDeUsuarios,200);
           
        }

        public function LoginUsuario($request,$response){
            $correo = $request->getParsedBody()['correo'];
            $clave = $request->getParsedBody()['clave'];

            $usuario='root';
            $pass='';
            $objetoPDO = new PDO('mysql:host=localhost;dbname=opticabd;charset=utf8', $usuario, $pass);
            $sql=$objetoPDO->prepare('SELECT correo,clave, perfil  FROM `usuarios` WHERE `correo` = :nombre AND `clave` = :clave');
            $sql->bindValue(':nombre', $correo);
            $sql->bindValue(':clave', $clave);
            $sql->execute();
            $result = $sql->rowCount();
            if($result)
            {
                $resultado=$sql->fetch();
                
                $correo= $resultado[0];
                $perfil=$resultado[2];
                $ahora=time();

                $payload = array(
                   'iat' => $ahora,
                   'exp'=> $ahora +(200),//20 segundos
                   'correo' => $correo,
                   'perfil'=>$perfil,
                   'app' => "probando"
                );
        
                $token = JWT::encode($payload, "miClave");
                
              //  $response->getBody()->write($token);      
                return $response->withJson($token,200);
            }
            else
            {
                return $response->withJson("Error");
            }
        
        }
    }

      


    
    
?>