<?php
  use \Firebase\JWT\JWT as jwt;
    class Anteojo{
        public function AgregarAnteojo($request,$response)//para el post
        {
           
                    $color = $request->getParsedBody()['color'];
                    $marca = $request->getParsedBody()['marca'];
                    $precio = $request->getParsedBody()['precio'];
                    $aumento = $request->getParsedBody()['aumento'];
                
                    $objetoPDO = new PDO('mysql:host=localhost;dbname=opticabd;charset=utf8', "root", "");
       
                        $consulta =$objetoPDO->prepare("INSERT INTO anteojos (color, marca, precio,aumento) VALUES(:color, :marca, :precio, :aumento)");
                    
                       
                        $consulta->bindValue(':color', $color, PDO::PARAM_STR);
                        $consulta->bindValue(':marca', $marca, PDO::PARAM_STR);
                        $consulta->bindValue(':precio', $precio,PDO::PARAM_STR);
                        $consulta->bindValue(':aumento',$aumento,PDO::PARAM_STR);

                        $consulta->execute(); 
                        $response->getBody()->write("Elemento agregado con exito");

                       // $response = $next($request, $response);
            
                return $response;

        }

        public function TraerTodosAnteojos($request,$response){
            $arrayDeMedias=array();
            $objetoPDO = new PDO('mysql:host=localhost;dbname=opticabd;charset=utf8', "root", "");
            $sql = $objetoPDO->prepare('SELECT * FROM anteojos');
            $sql->execute();
            
            while($result = $sql->fetchObject())
            {
             /*PARA MOSTRAR PROLIJO  
             echo $result->color." ".$result->talle." ".$result->precio." ".$result->marca."<br>";
             */
                array_push($arrayDeMedias,$result);
            }
            $cant= count($arrayDeMedias);
           /* for($i=0;$i<$cant;$i++){
             $response->getBody()->write(  $arrayDeMedias[$i]->color." ".$arrayDeMedias[$i]->marca ." ".$arrayDeMedias[$i]->talle." ".$arrayDeMedias[$i]->precio."<br>");
            }*/
         //
         
         $nuevoResponse=$response->withJson($arrayDeMedias);
            return $nuevoResponse;
           
        }


        public function EliminarAnteojo($request,$response){
                $token = $request->getParsedBody()['token'];
                $id = $request->getParsedBody()['id'];
             //   if(Media::EsPropietario($token)){

                $objetoPDO2 = new PDO('mysql:host=localhost;dbname=opticabd;charset=utf8', "root", "");
                    //Veo si existe el cd en la BD, para en un futuro pedir confirmacion antes de eliminar.
                $sql =$objetoPDO2->prepare("SELECT * FROM anteojos WHERE id = :id");
                $sql->bindValue(':id', $id);
                $sql->execute();
              
                $result = $sql->rowCount();

               
               if($result==1){//suponiendo que no TIENEN QUE EXIsTIR DOS CDS IGUALES
                   
                    //¿Como saber el ID del CD resultado de la consulta?
                    $resultado=$sql->fetch();
                    $id= $resultado[0];
                   // $pathFoto=$resultado[4];
                   
                   
                    $sql =$objetoPDO2->prepare("DELETE FROM anteojos WHERE id = :id");
                    $sql->bindValue(':id', $id);
                    $sql->execute();
                    

                   // return   $response->withJson("Media eliminado");
                 return  $response->getBody()->write("Elemento eliminado con exito");
                } else
                {
                    
                    return $response->getBody()->write("Elemento inexistente");
                }
        //    }else{

                $response->getBody()->write("Error.");
               // return $response->withJson("Error");
                //$response->withJson("Solo propietario");
          //  }
            return $response;

        }

        public static function EsPropietario($token){
          //desencriptar token, verificar el perfil, retronar true o false
          if(empty($token) || $token === "")
          {
              echo "el token esta vacio";
          }
          try
          {
              $jwtDecode = JWT::decode($token,'miClave',array('HS256'));

              if($jwtDecode->perfil=="propietario"){
                    return true;
              }else{
                  return false;
              }
           }
           catch(Exception $e){

              return false;
           }
         

        }

        public static function EsEncargado($token){
            if(empty($token) || $token === "")
            {
                echo "el token esta vacio";
            }
            try
            {
                $jwtDecode = JWT::decode($token,'miClave',array('HS256'));
  
                if($jwtDecode->perfil=="encargado" || $jwtDecode->perfil=="Encargado"){
                      return true;
                }else{
                    return false;
                }
             }
             catch(Exception $e){
  
                return false;
             }
        }
        public static function ModificarAnteojo($request,$response){
            $token = $request->getParsedBody()['token'];
            $id = $request->getParsedBody()['id'];
            $color=$request->getParsedBody()['color'];
            $aumento= $request->getParsedBody()['aumento'];
            $marca= $request->getParsedBody()['marca'];
            $precio= $request->getParsedBody()['precio'];
         //   if(Media::EsPropietario($token) || Media::EsEncargado($token)){
                $objetoPDO2 = new PDO('mysql:host=localhost;dbname=opticabd;charset=utf8', "root", "");
                    //Veo si existe el cd en la BD, para en un futuro pedir confirmacion antes de eliminar.
                $sql =$objetoPDO2->prepare("SELECT * FROM anteojos WHERE id = :id");
                $sql->bindValue(':id', $id);
                $sql->execute();
              
                $result = $sql->rowCount();

               
               if($result==1){//suponiendo que no TIENEN QUE EXIsTIR DOS CDS IGUALES
                   
                    //¿Como saber el ID del CD resultado de la consulta?
                    $resultado=$sql->fetch();
                    $id= $resultado[0];
                   // $pathFoto=$resultado[4];
                   
                    $sql =$objetoPDO2->prepare("UPDATE anteojos SET color=:color,aumento=:aumento, marca=:marca , precio=:precio WHERE id = :id");
                    $sql->bindValue(':color',$color);
                    $sql->bindValue(':aumento',$aumento);
                    $sql->bindValue(':marca',$marca);
                    $sql->bindValue(':precio',$precio);
                    $sql->bindValue(':id', $id);
                    $sql->execute();

                   // return   $response->withJson("Media eliminado");
                 return  $response->getBody()->write("Elemento modificado con exito");
                } else
                {
                    
                    $response->getBody()->write("Elemento inexistente");
                }
           // }else{

                $response->getBody()->write("Error.");
             
             
                // return $response->withJson("Error");
                //$response->withJson("Solo propietario");
            //}
            return $response;
            }
        }


    
    
?>